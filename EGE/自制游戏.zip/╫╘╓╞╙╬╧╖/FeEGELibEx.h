#ifndef _FEEGELIBEX_
#define _FEEGELIBEX_

#include "FeEGELib.h"
using namespace FeEGE;

class ElementEx;

class ElementEx : public Element{
};
